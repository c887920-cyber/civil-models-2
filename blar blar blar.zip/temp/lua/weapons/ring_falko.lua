if SERVER then
	AddCSLuaFile( "ring_falko.lua" )
end

SWEP.Category				= "The One Ring"
SWEP.Author				= "Falko"
SWEP.Contact				= "Falko"
SWEP.Purpose				= ""
SWEP.Instructions				= "Ash nazg durbatulûk. Ash nazg gimbatul. Ash nazg thrakatulûk agh burzum-ishi krimpatul."
SWEP.PrintName				= "One Ring"	
SWEP.Slot				= 2				
SWEP.SlotPos				= 27			
SWEP.DrawAmmo				= true		
SWEP.DrawWeaponInfoBox			= false		
SWEP.BounceWeaponIcon   		= 	false	
SWEP.DrawCrosshair			= false		
SWEP.Weight				= 30			
SWEP.AutoSwitchTo			= true		
SWEP.AutoSwitchFrom			= true		
SWEP.HoldType 				= "idle"	

SWEP.ViewModelFOV			= 60
SWEP.ViewModelFlip			= false
SWEP.ViewModel				= "models/weapons/ring_falko.mdl"	-- Weapon view model
SWEP.WorldModel				= ""	-- Weapon world model
SWEP.ShowWorldModel			= true
SWEP.Base				= ""
SWEP.Spawnable				= true
SWEP.UseHands = true
SWEP.AdminSpawnable			= true
SWEP.FiresUnderwater = false

SWEP.RunSightsPos = Vector(0, 0, 0)
SWEP.RunSightsAng = Vector(-25.577, 0, 0)

SWEP.Slash = 1

function SWEP:Deploy()
	if not IsFirstTimePredicted() then return end
    self:SetHoldType(self.HoldType)
    self.Weapon:SendWeaponAnim( ACT_VM_DRAW )
    self.Invisible = false
    return true
end

function SWEP:Holster()
    self.Invisible = false
	self.Owner:StopSound("wind")
	self.Owner:StopSound("ring")
    return true
end    

function SWEP:DrawHUD()
	if self.Invisible == true then
        surface.SetDrawColor(255,255,255,255)
        surface.SetMaterial(Material("effects/invuln_overlay_red"))
        surface.DrawTexturedRect(0,0,ScrW(),ScrH())

	else
		surface.SetDrawColor(255,255,255,0)
        surface.SetMaterial(Material("effects/invuln_overlay_red"))
        surface.DrawTexturedRect(0,0,ScrW(),ScrH())
	end
end

sound.Add( {
    name = "wind",
    channel = CHAN_AUTO,
    volume = 1.0,
    level = 80,
    pitch = {95, 110},
    sound = "wind.mp3"
} )

sound.Add( {
    name = "ring",
    channel = CHAN_AUTO,
    volume = 1.0,
    level = 80,
    pitch = {95, 110},
    sound = "ring.mp3"
} )

function SWEP:PrimaryAttack()
	if not IsFirstTimePredicted() then return end
	if (IsValid(self.Owner)) then
		if self.Invisible == false then
			self.Weapon:SetNextPrimaryFire(CurTime() + 2)
			self.Owner:DrawViewModel(true)
			self.Owner:SetAnimation( ACT_VM_PRIMARYATTACK )
			self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
			timer.Simple(2, function() 
				self.Owner:DrawViewModel(false)
				self.Owner:SetNoDraw(true)
				self.Owner:SetHealth(self.Owner:GetMaxHealth()+300)
				self.Owner:EmitSound("wind")
				if (SERVER) then
					self.Owner:SetNoTarget(true)
				end
				self.Invisible = true 
			end)
		else
			self.Weapon:SetNextPrimaryFire(CurTime() + 2)
			self.Owner:DrawViewModel(true)
			self.Owner:SetAnimation( ACT_VM_SECONDARYATTACK )
			self.Weapon:SendWeaponAnim( ACT_VM_SECONDARYATTACK )
			timer.Simple(2, function()
				self.Owner:StopSound("wind")
				self.Owner:SetNoDraw(false)
				if (SERVER) then
					self.Owner:SetNoTarget(false)
				end
				print(self.Owner:IsFlagSet( FL_NOTARGET ))
				self.Invisible = false
			end)
		end
	end
end

function SWEP:SecondaryAttack()
	if not IsFirstTimePredicted() then return end
	if (IsValid(self.Owner)) then
		if self.Invisible == true then
			self.Owner:EmitSound("ring")
		else
			self.Owner:StopSound("ring")
		end
	end
end

hook.Add( "GetFallDamage", "RealisticDamage", function( ply, speed )
	if ply:GetActiveWeapon().Invisible == true then
    	return 0
	end
end )


hook.Add("PlayerFootstep", "PlayerFootstepRing", function(ply,pos,foot,sound,volume)
	if ply:GetActiveWeapon():GetClass() == "ring_falko" and ply:GetActiveWeapon().Invisible == true then
		return true
	end
end)

local tab = {
	["$pp_colour_addr"] = 0,
	["$pp_colour_addg"] = 0,
	["$pp_colour_addb"] = 0,
	["$pp_colour_brightness"] = -0.00,
	["$pp_colour_contrast"] = 1,
	["$pp_colour_colour"] = 0,
	["$pp_colour_mulr"] = 0,
	["$pp_colour_mulg"] = 0,
	["$pp_colour_mulb"] = 0
}

if (CLIENT) then
	hook.Add("RenderScreenspaceEffects", "PostProcessingExample", function()
		if (IsValid(LocalPlayer())) then
			if LocalPlayer():GetActiveWeapon().Invisible == true then
				DrawColorModify( tab ) --Draws Color Modify effect
				DrawSobel( 0.5 ) --Draws Sobel effect
			end
		end
	end)
end