player_manager.AddValidModel("Satoru Gojo (Young)", "models/sazuma/gojo.mdl")
list.Set("PlayerOptionsModel", "Satoru Gojo (Young)", "models/sazuma/gojo.mdl")
player_manager.AddValidHands( "Satoru Gojo (Young)", "models/sazuma/gojo_arms.mdl", 0, "0000000" )