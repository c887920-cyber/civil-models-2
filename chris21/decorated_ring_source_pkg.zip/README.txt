Accessory Source compile package
Contents:
 - models/decorated_ring/reference.smd
 - models/decorated_ring/idle.smd
 - models/decorated_ring/model.qc
 - materials/decorated_ring/* (textures and .vmt files)

To compile to .mdl (using Crowbar on Windows):
 1. Open Crowbar -> Decompile/Compile -> Compile
 2. Set QC path to models/decorated_ring/model.qc
 3. Set output path and run Compile (Crowbar uses studiomdl.exe internally)

If you prefer to use studiomdl.exe directly, make sure you set $modelname and $cdmaterials correctly.

Notes:
 - This SMD exporter is rigid (single bone "root"). For animated models you will need proper skeletons/animations.
 - If the model appears inverted/rotated in Source, try adjusting $origin or using $scale -1 1 1 in the QC.
