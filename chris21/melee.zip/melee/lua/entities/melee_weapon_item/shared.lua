ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "melee"
ENT.Author = ""
ENT.Category = "melee stuff"
ENT.Spawnable = false
ENT.AdminSpawnable = false
