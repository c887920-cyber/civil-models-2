
-------------------------------
AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )
include( 'shared.lua' )
-------------------------------

ENT.Weapon = ""
ENT.Delay = 0

----------------
-- Initialize --
----------------
function ENT:Initialize()
	
	self.Entity:SetModel( "models/Items/BoxBuckshot.mdl" )
	local phys = self.Entity:GetPhysicsObject()
	if (phys:IsValid()) then
		phys:Wake()
	end
	
	self.Delay = CurTime() + 1

end

function ENT:Think()

end

function ENT:PhysicsCollide( data, phys )
	if ( data.Speed > 200 ) then 
		self:EmitSound( "physics/metal/metal_canister_impact_hard3.wav" ) 
	end
	local ent = data.HitEntity
	if data.Speed > 500 then
		if ent:IsPlayer() or ent:IsNPC() then
			local dmginfo = DamageInfo()
			dmginfo:SetDamageType(DMG_CLUB)
			dmginfo:SetAttacker(self)
			dmginfo:SetInflictor(self)
			dmginfo:SetDamage(25)
			dmginfo:SetDamageForce(data.OurOldVelocity*10)
			
			ent:TakeDamageInfo(dmginfo)
			ent:EmitSound( "physics/flesh/flesh_impact_bullet5.wav" )
		end
	end
end

------------
-- On use --
------------
function ENT:Use( activator, caller )
local ply = activator
	if ply:IsPlayer() and self.Delay < CurTime() then
		ply:Give(self.Weapon)
		ply:SelectWeapon(self.Weapon)
		self.Entity:Remove()
	end
end
