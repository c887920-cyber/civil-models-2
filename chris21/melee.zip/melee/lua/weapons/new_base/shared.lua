
SWEP.BounceWeaponIcon  = false

SWEP.PrintName		= "cool base"
SWEP.Author			= "hoobsug"
SWEP.Contact		= "https://steamcommunity.com/id/hoobsucc/"
SWEP.Purpose		= ""
SWEP.Instructions	= ""

SWEP.ViewModel		= "models/weapons/c_357.mdl"
SWEP.WorldModel		= "models/weapons/w_357.mdl"

SWEP.Ironsights = true

SWEP.IronsightPos = Vector(-2.651, -2, 1.049)
SWEP.IronsightAng = Vector(-0.5, 0, 0)

SWEP.IronsightZoom = 0
SWEP.SightsConeMul = 0.9
SWEP.AimMouseSensetivity = 0.5

SWEP.HoldType		= "pistol"

SWEP.Category		= "COOL BASE"

SWEP.Spawnable			= false
SWEP.AdminSpawnable		= false

SWEP.Primary.Recoil			= 0.5

SWEP.Primary.Damage			= 40  
SWEP.Primary.NumShots		= 1
SWEP.Primary.Cone			= 0.2

SWEP.Primary.Delay			= 0.1

SWEP.Primary.Force			= 3

SWEP.Primary.ClipSize		= 30
SWEP.Primary.TakeAmmo		= 1
SWEP.Primary.DefaultClip	= 30
SWEP.Primary.Automatic		= true
SWEP.Primary.Ammo			= "ar2"

SWEP.ProjectileVelocity		= 10000
SWEP.Throwable				= false
SWEP.Melee					= false
SWEP.MeleeRange				= 64

SWEP.MeleeHitSound = "weapons/loh"	--без рандомного числа и формата
SWEP.HitSoundMaxRand = 6
SWEP.HitSoundFormat = ".wav"

SWEP.UseHands = true

SWEP.Secondary.ClipSize		= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Automatic	= false
SWEP.Secondary.Ammo			= "none"

SWEP.PrimarySound			= ""

SWEP.SwayScale			= 1.0
SWEP.BobScale			= 1.0

if (SERVER) then

	AddCSLuaFile( "shared.lua" )
	SWEP.Weight				= 5
	SWEP.AutoSwitchTo		= false
	SWEP.AutoSwitchFrom		= false

end

if ( CLIENT ) then

	SWEP.DrawAmmo			= true
	SWEP.DrawCrosshair		= false
	SWEP.ViewModelFOV		= 50
	SWEP.ViewModelFlip		= false
	
end

function SWEP:SetupDataTables()

	self:NetworkVar( "Bool", 1, "AimBool" )
	self:NetworkVar( "Float", 1, "NextReload" )
	self:NetworkVar( "Bool", 2, "Holster" )
	self:NetworkVar( "Bool", 3, "Running" )
	self:NetworkVar( "Float", 2, "HolsterDelay" )
	self:NetworkVar( "Bool", 4, "Reloading" )
	self:NetworkVar( "Bool", 5, "ThrowHolding" )
	self:NetworkVar( "Float", 3, "MeleeStep" )
	self:NetworkVar( "Float", 4, "Alert" )
	
	self:SetAimBool( false )
	self:SetNextReload( 0 )
	self:SetHolster( false )
	self:SetRunning( false )
	self:SetHolsterDelay( 0 )
	self:SetReloading( false )
	self:SetThrowHolding( false )
	
	self:SetMeleeStep( 1 )
	self:SetAlert( 0 )
	
end

function SWEP:Initialize()

	if ( SERVER ) then
		self:SetNPCMinBurst( 30 )
		self:SetNPCMaxBurst( 30 )
		self:SetNPCFireRate( 0.01 )
	end
	
	self:SetHoldType( self.HoldType )

end

SWEP.DefaultAuto = false

function SWEP:Deploy()

	self.Weapon:SendWeaponAnim(ACT_VM_DRAW)
	
	self.Weapon:SetNextPrimaryFire(CurTime() + self.Weapon:SequenceDuration())
	self.Weapon:SetNextSecondaryFire(CurTime() + self.Weapon:SequenceDuration())
	self:SetNextReload( CurTime() + self.Weapon:SequenceDuration() )
	self.idledelay = ( CurTime() + self.Weapon:SequenceDuration() )
	self.throw_delay = ( CurTime() + self.Weapon:SequenceDuration() )
	
	self:SetHolster(false)
	self:SetRunning(false)
	self:SetMeleeStep( 1 )

	return true
end

function SWEP:Reload()
	if not SERVER then return end
	if self:GetThrowHolding() then
		self.idledelay = CurTime() + 0
		self.throw_delay = CurTime() + 1
		self:SetThrowHolding(false)
		self.Owner:ViewPunch( Angle( 2, 0, 0 ) )
		return
	end

	if !self:CanReload() or !self:CanPrimaryAttack() or self.throw_delay > CurTime() then return end
	
	if self:GetMeleeStep() == 1 then
		self.Weapon:SendWeaponAnim(ACT_VM_RELOAD)
		self:SetMeleeStep(5)
		self.Owner:ViewPunch( Angle( 2, 0, 0 ) )
		self.idledelay = CurTime() + self.Weapon:SequenceDuration()
		self:SetNextPrimaryFire( CurTime() + self.Weapon:SequenceDuration() )
		self:SetNextReload(CurTime() + self.Weapon:SequenceDuration())
	elseif self:GetMeleeStep() == 5 then
		self.Weapon:SendWeaponAnim(ACT_VM_RELOAD_SILENCED)
		self:SetMeleeStep(1)
		self.Owner:ViewPunch( Angle( 2, 0, 0 ) )
		self.idledelay = CurTime() + self.Weapon:SequenceDuration()
		self:SetNextPrimaryFire( CurTime() + self.Weapon:SequenceDuration() )
		self:SetNextReload(CurTime() + self.Weapon:SequenceDuration())
	end
	
end

function SWEP:CanReload()
	if self:GetNextReload() > CurTime() then 
		return false
	end
	return true
end

function SWEP:FireProjectile()
	local ent = ents.Create( "melee_weapon_item" )
	if ( IsValid( ent ) ) then
		local Forward = self.Owner:EyeAngles():Forward()
		local Right = self.Owner:EyeAngles():Right()
		local Up = self.Owner:EyeAngles():Up()
		ent:SetPos( self.Owner:GetShootPos() + Forward * 24 + Right * 8 + Up * -4)
		ent:SetAngles( self.Owner:EyeAngles() )
		ent:Spawn()
		ent:SetModel(self.WorldModel)
		ent:PhysicsInit( SOLID_VPHYSICS )
		ent:SetMoveType( MOVETYPE_VPHYSICS )
		ent:SetSolid( SOLID_VPHYSICS )
		
		ent.Weapon = self:GetClass()
		
		local phys = ent:GetPhysicsObject()
		local force = self.ProjectileVelocity
		phys:SetVelocity(self.Owner:GetAimVector() * force)
		if self.Throwable then
			phys:AddAngleVelocity(Vector(math.random(-1000, 1000), math.random(-1000, 1000), math.random(-1000, 1000)))
		end
		ent:SetCollisionGroup(COLLISION_GROUP_PROJECTILE)
	end
end

SWEP.melee_delay = 0
SWEP.melee_striking = false

SWEP.MeleeHitDelay = 0.1

function SWEP:PrimaryAttack()

	if !self:CanPrimaryAttack() or self:GetRunning() or ((self:GetNextReload() > CurTime()) or (self:GetNextReload()-0.3 > CurTime())) then return end

	if self:GetMeleeStep() == 1 then
		self.Weapon:SendWeaponAnim(ACT_VM_HITRIGHT)
		self:SetMeleeStep(2)
		self.Owner:ViewPunch( Angle( 2, 2, -1 ) )
	elseif self:GetMeleeStep() == 2 then
		self.Weapon:SendWeaponAnim(ACT_VM_HITLEFT)
		self:SetMeleeStep(3)
		self.Owner:ViewPunch( Angle( 2, -2, 1 ) )
	elseif self:GetMeleeStep() == 3 then
		self.Weapon:SendWeaponAnim(ACT_VM_SECONDARYATTACK)
		self:SetMeleeStep(1)
		self.Owner:ViewPunch( Angle( 4, 1, 0 ) )
	elseif self:GetMeleeStep() == 5 then
		self.Weapon:SendWeaponAnim(ACT_VM_MISSRIGHT)
		self.Owner:ViewPunch( Angle( 2, 1, 0 ) )
	elseif self:GetMeleeStep() == 6 then
		self.Weapon:SendWeaponAnim(ACT_VM_PRIMARYATTACK_SILENCED)
		self.Owner:ViewPunch( Angle( 3, 1, 0 ) )
	end
	
	if self:GetMeleeStep() == 5 then
		self:SetNextPrimaryFire( CurTime() + self.Primary.Delay/1.5 )
		self:SetAlert( CurTime() + 4 )
	elseif self:GetMeleeStep() == 6 then
		self:SetNextPrimaryFire( CurTime() + self.Weapon:SequenceDuration() )
		self:SetAlert( CurTime() + self.Weapon:SequenceDuration() )
		local eyeang = self.Owner:EyeAngles()
		eyeang.p = 5
		self.Owner:SetEyeAngles(eyeang)
	else
		self:SetNextPrimaryFire( CurTime() + self.Primary.Delay )
		self:SetAlert( CurTime() + 4 )
	end

	self:EmitSound(Sound(self.Primary.Sound))
	self.melee_delay = CurTime() + self.Weapon:SequenceDuration()*self.MeleeHitDelay
	self.melee_striking = true
	
	self.Owner:SetAnimation(PLAYER_ATTACK1)
	
	self.idledelay = CurTime() + self.Weapon:SequenceDuration()
	
	--self:SetNextReload(CurTime() + self.Weapon:SequenceDuration())
	self:SetReloading(false)
	
end

function SWEP:SecondaryAttack()	

end

function SWEP:CanPrimaryAttack()

	if self:GetNextPrimaryFire() > CurTime() or self:GetThrowHolding() then return end

	if !self.Melee then
		if (self:Clip1() <= 0 and self:Clip1() <= 1) then
					--self:DryFire()
				self:SetNextPrimaryFire( CurTime() + 0.3 )
				self:SetNextSecondaryFire( CurTime() + 0.3 )		
			return false
	 
		end
	end
 
	return true
end

SWEP.ChangeTo = nil

SWEP.throwing = false
SWEP.gren_delay = 0
SWEP.thrown = false

SWEP.StealthCharged = false
SWEP.NxtStealth = 0

function SWEP:IsBehind(target)

	local dir = target:GetPos() - self.Owner:GetShootPos() 
	return target:GetAimVector():Dot(dir) > math.sin(30)
	
end

SWEP.CanThrow = true

function SWEP:Think()

	if not self.Owner:IsPlayer() then return end
	
	if SERVER then
		
		local tr = self.Owner:GetEyeTrace()
		
		if self:GetNextPrimaryFire() < CurTime() then
			if ( tr.Entity:IsNPC() or tr.Entity:IsPlayer() ) and self.Owner:GetPos():DistToSqr(tr.Entity:GetPos()) < (self.MeleeRange*self.MeleeRange) and self:IsBehind(tr.Entity) then
				if !self.StealthCharged and self.NxtStealth < CurTime() then
					if self:GetMeleeStep() == 5 then
						self.Weapon:SendWeaponAnim( ACT_VM_ATTACH_SILENCER )
						self:SetHoldType( "melee" )
						self:SetNextPrimaryFire( CurTime() + self.Weapon:SequenceDuration() )
						self.StealthCharged = true
						self:SetMeleeStep(6)
						self.idledelay = CurTime() + 0.5
						self.Owner:ViewPunch( Angle( -1, 0, 0 ) )
					end
				end
			else
				if self.StealthCharged then
					self.StealthCharged = false
					self.idledelay = 0
					self.NxtStealth = CurTime() + 0.5
				end
			end
		end
		
		if !self.CanThrow then
			if !self.Owner:KeyDown(IN_ATTACK2) then
				self.CanThrow = true
			end
		end
		
		if self.Throwable then
			if !self:GetThrowHolding() then
				if !self.StealthCharged and !self.throwing and self.throw_delay < CurTime() and self.CanThrow then
					if self.Owner:KeyDown(IN_ATTACK2) then
						if self:GetMeleeStep() != 5 then
							self.Weapon:SendWeaponAnim( ACT_VM_PULLBACK_HIGH )
						else
							self.Weapon:SendWeaponAnim( ACT_VM_PULLBACK_LOW )
						end
						self:SetHoldType( "melee" )
						self.throw_delay = CurTime() + self.Weapon:SequenceDuration()
						self:SetNextReload( CurTime() + self.Weapon:SequenceDuration() )
						self:SetThrowHolding(true)
						self.CanThrow = false
						self.Owner:ViewPunch( Angle( -1, 0, -1 ) )
					end
				end
			else
				
				if self.throw_delay < CurTime() then	
					if !self.Owner:KeyDown(IN_ATTACK2) then
						self.Weapon:SendWeaponAnim( ACT_VM_PRIMARYATTACK )
						self.idledelay = CurTime() + self.Weapon:SequenceDuration()
						self.throw_delay = CurTime() + self.Weapon:SequenceDuration()
						self:SetNextPrimaryFire( CurTime() + self.Weapon:SequenceDuration() )
						self.gren_delay = CurTime() + 0.2
						self.throwing = true
						self:SetThrowHolding(false)
						self.Owner:ViewPunch( Angle( 3, 0, 0 ) )
					end
				end
				
			end
			
			if self.throwing then
				if self.gren_delay < CurTime() then 
					self:FireProjectile(self.low_throw)
					self.throwing = false
					self.thrown = true
				end
			end
			
			if self.throw_delay < CurTime() and self.thrown then
				self.Owner:StripWeapon(self.Weapon:GetClass())
			end
			
		end
		
		if self.melee_striking then
			if self.melee_delay < CurTime() then
				local tr = util.TraceHull( {
					start = self.Owner:GetShootPos(),
					endpos = self.Owner:GetShootPos() + ( self.Owner:GetAimVector() * self.MeleeRange ),
					filter = self.Owner,
					mins = Vector( -10, -10, -10 ),
					maxs = Vector( 10, 10, 10 ),
					mask = MASK_SHOT_HULL
				} )
				
				if ( tr.Hit ) then
					local dmginfo = DamageInfo()
					dmginfo:SetDamageType(DMG_CLUB)
					dmginfo:SetAttacker(self.Owner)
					dmginfo:SetInflictor(self)
					if self.StealthCharged then
						dmginfo:SetDamage(100)
						self.StealthCharged = false
					else
						dmginfo:SetDamage(15)
					end
					
					self.Owner:EmitSound(self.MeleeHitSound..math.random(1, self.HitSoundMaxRand)..self.HitSoundFormat)
					self.Owner:ViewPunch( Angle( math.Rand(1,2), math.Rand(-1,1), 0 ) )

					if tr.Entity:IsNPC() or tr.Entity:IsPlayer() then
						dmginfo:SetDamageForce(self.Owner:GetForward()*3000)
						
						if self:GetMeleeStep() >= 5 then
							local fx = EffectData()
							fx:SetEntity(tr.Entity) 
							fx:SetOrigin(tr.HitPos)
							fx:SetNormal(tr.HitNormal)
							fx:SetColor(tr.Entity:GetBloodColor())
							if tr.MatType == MAT_FLESH or tr.MatType == MAT_ALIENFLESH then
								util.Effect("BloodImpact", fx)
							end
						end
						
					else
						if IsValid(tr.Entity:GetPhysicsObject()) then
							tr.Entity:GetPhysicsObject():ApplyForceCenter(self.Owner:GetForward()*3000)
						end
					end
					
					tr.Entity:TakeDamageInfo(dmginfo)
				else
					self.Owner:ViewPunch( Angle( 0.5, 0, 0 ) )
				end
				
				self.melee_striking = false
				
			end
		end
		
		if self.idledelay < CurTime() and !self.throwing and !self.StealthCharged and !self:GetHolster() and self:GetNextPrimaryFire() < CurTime() and !self:GetThrowHolding() and self:GetNextReload() < CurTime() then
			
			if self:GetAlert() < CurTime() and self:GetMeleeStep() != 1 and self:GetMeleeStep() != 5 then
				if self:GetMeleeStep() == 6 then
					self:SetMeleeStep(5)
				else
					self:SetMeleeStep(1)
				end
			end
			
			if self:GetMeleeStep() == 1 then
				self.Weapon:SendWeaponAnim(ACT_VM_IDLE)
			elseif self:GetMeleeStep() == 2 then
				self.Weapon:SendWeaponAnim(ACT_VM_IDLE_LOWERED)
			elseif self:GetMeleeStep() == 3 then
				self.Weapon:SendWeaponAnim(ACT_VM_IDLE_SILENCED)
			elseif self:GetMeleeStep() == 5 then
				self.Weapon:SendWeaponAnim(ACT_VM_IDLE_EMPTY)
			end
			self:SetHoldType( self.HoldType )
			self.idledelay = CurTime() + self.Weapon:SequenceDuration()
		end

	end

	if self:GetHolster() and self:GetHolsterDelay() < CurTime() then
		if not IsFirstTimePredicted() then return end
		if SERVER then 
			if self.OneShot and self:Clip1() == 0 then
				self.Owner:StripWeapon(self.Weapon:GetClass())
			else
				self.Owner:SelectWeapon(self.ChangeTo)
			end		
		end
	end
	
end

local aimlerp = 0

function SWEP:GetViewModelPosition( pos, ang )

if !CLIENT then return end

local FT = FrameTime()
local pitch = self.Owner:EyeAngles().pitch

	if self:GetAimBool() and self:GetNextReload() < CurTime() then
		aimlerp = Lerp(FT*9, aimlerp, 1)
		self.SwayScale 	= 0.1
		self.BobScale 	= 0.1
	else
		aimlerp = Lerp(FT*9, aimlerp, 0)	
		self.SwayScale 	= 1.0
		self.BobScale 	= 1.0
	end

	ang:RotateAroundAxis( ang:Right(), (self.IronsightAng.x * aimlerp) )
	ang:RotateAroundAxis( ang:Up(), (self.IronsightAng.y * aimlerp) )
	ang:RotateAroundAxis( ang:Forward(), (self.IronsightAng.z * aimlerp) )
	
	pos = pos+(ang:Right()*(self.IronsightPos.x*aimlerp))+(ang:Forward()*((self.IronsightPos.y*aimlerp)))+(ang:Up()*(self.IronsightPos.z*aimlerp))
	
	return pos, ang
	
end

local att_ang = Angle(0,0,0)
local att_pos = Vector(0,0,0)

local newang = Angle(0,0,0)
local zeroang = Angle(0,0,0)
local zeropos = Vector(0,0,0)
local clamped = 0

local alert_mul = 0

SWEP.ReloadBobMul = 1

function SWEP:CalcView( ply, pos, ang, fov ) 

	if self:GetNextReload()-0.2 >= CurTime() then
		newang = LerpAngle(FrameTime()*25, newang, (ang-att_ang)*0.1)
	else
		newang = LerpAngle(FrameTime()*1, newang, zeroang)
	end
	
	if (self:GetMeleeStep() != 1 and self:GetMeleeStep() != 5 and self:GetMeleeStep() != 6) or self:GetThrowHolding() then
		alert_mul = Lerp(FrameTime() * 5, alert_mul, 0.5)
	else
		alert_mul = Lerp(FrameTime() * 5, alert_mul, 0)
	end
	
	ang:RotateAroundAxis( ang:Right(), (newang.p*0.8)*-1*self.ReloadBobMul )
	
	--===========sick fixes===========--
	clamped = Lerp(FrameTime()*10, clamped, math.Clamp(newang.y, -1, 1))
	
	ang:RotateAroundAxis( ang:Up(), clamped*self.ReloadBobMul + (math.sin(CurTime()*2)*alert_mul))
	ang:RotateAroundAxis( ang:Forward(), ((newang.p + newang.r) * 0.1)*self.ReloadBobMul)
	ang:RotateAroundAxis( ang:Right(), (math.sin(CurTime()*4)*alert_mul))

	return pos, ang, fov

end

function SWEP:Holster(wep)
	if not IsFirstTimePredicted() then return end
	if self:IsValid() and self.Owner:IsValid() then
		
		if IsValid(wep) and self:GetNextPrimaryFire() < CurTime() and !self:GetHolster() then
			self.idledelay = 0
			self.Weapon:SendWeaponAnim(ACT_VM_HOLSTER)
			self:SetNextReload( CurTime() + self.Weapon:SequenceDuration() )
			self:SetNextPrimaryFire(CurTime() + self.Weapon:SequenceDuration() )
			self:SetNextSecondaryFire(CurTime() + self.Weapon:SequenceDuration() )
			self:SetHolster(true)
			--self:EmitSound(self.HolsterSound, 100, 100)
			self:SetHolsterDelay( CurTime() + self.Weapon:SequenceDuration() )
			if SERVER then self.ChangeTo = wep:GetClass() end
		elseif self:GetHolster() and self:GetHolsterDelay() <= CurTime() then
			if SERVER then self.ChangeTo = nil end
			if CLIENT then self:ResetBones() else self:CallOnClient("ResetBones") end
			return true
		end
	end
	return false
end

local sense_mod = 1

function SWEP:AdjustMouseSensitivity()
	
	if !self:GetAimBool() then 
		sense_mod = 1 
		else
		sense_mod = self.AimMouseSensetivity
	end
	
	return sense_mod

end

function SWEP:DrawHUD()

	local vm = self.Owner:GetViewModel()
	local att = vm:GetAttachment(3)

	--PrintTable(vm:GetAttachments())

	if att then
		att_ang = att.Ang
		att_pos = att.Pos
	end

end

function SWEP:PreDrawViewModel(vm, wep, ply)

end


function SWEP:TranslateFOV( current_fov )

end

function SWEP:ResetBones()

	local vm = self.Owner:GetViewModel()
	if not IsValid(vm) then return end
	
	if (!vm:GetBoneCount()) then return end
	
	for i = 0, vm:GetBoneCount() do
		vm:ManipulateBoneScale( i, Vector(1, 1, 1) )
		vm:ManipulateBoneAngles( i, Angle(0, 0, 0) )
		vm:ManipulateBonePosition( i, Vector(0, 0, 0) )
	end
	
end
