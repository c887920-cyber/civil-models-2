player_manager.AddValidModel( "revantimb", "models/grealms/characters/revan_real/revantimb.mdl" );
list.Set( "PlayerOptionsModel", "revantimb", "models/player/valley/revantimb.mdl" );